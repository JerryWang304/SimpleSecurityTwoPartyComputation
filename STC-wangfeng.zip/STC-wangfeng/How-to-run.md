- server.py :  Alice
- client.py  :  Bob

Firstly, run server.py. Input n and then input an integer, which is Ailce's wealth. For simplicity, server.py wil conver the integer to n-bits binary number. In client, you also need to input Bob's wealth. The code will yield the result, just wait if n is too big. After a successful running, you should wait for the socket to expire if you want to test another n. Or you can modify the port in my codes.